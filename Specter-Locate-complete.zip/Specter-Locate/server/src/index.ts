import "dotenv/config";
import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import { Pool } from "pg";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const port = Number(process.env.PORT ?? 3000);
const secret = process.env.JWT_SECRET;
if (!secret) throw new Error("JWT_SECRET is required");

const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL })
  : null;

type Claims = { sub: string };

function authenticate(req: express.Request): Claims | null {
  const header = req.header("authorization");
  if (!header?.startsWith("Bearer ")) return null;
  try {
    return jwt.verify(header.slice(7), secret) as Claims;
  } catch {
    return null;
  }
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "specter-locate" });
});

app.post("/api/v1/auth/demo", (req, res) => {
  const userId = String(req.body?.userId ?? "").trim();
  if (!userId || userId.length > 128) {
    return res.status(400).json({ error: "invalid_user_id" });
  }
  const token = jwt.sign({ sub: userId }, secret, { expiresIn: "30d" });
  return res.json({ token });
});

app.post("/api/v1/locations/batch", async (req, res) => {
  const claims = authenticate(req);
  if (!claims) return res.status(401).json({ error: "unauthorized" });
  if (!pool) return res.status(503).json({ error: "database_not_configured" });

  const points = req.body?.points;
  if (!Array.isArray(points) || points.length > 500) {
    return res.status(400).json({ error: "invalid_batch" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    for (const point of points) {
      const lat = Number(point.latitude);
      const lon = Number(point.longitude);
      const accuracy = Number(point.accuracy);
      const capturedAt = Number(point.capturedAt);

      if (
        !Number.isFinite(lat) || lat < -90 || lat > 90 ||
        !Number.isFinite(lon) || lon < -180 || lon > 180 ||
        !Number.isFinite(capturedAt)
      ) {
        return res.status(400).json({ error: "invalid_location" });
      }

      await client.query(
        `INSERT INTO location_points
         (user_id, latitude, longitude, accuracy, captured_at)
         VALUES ($1, $2, $3, $4, to_timestamp($5 / 1000.0))`,
        [claims.sub, lat, lon, Number.isFinite(accuracy) ? accuracy : null, capturedAt]
      );
    }

    await client.query("COMMIT");
    return res.status(204).end();
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);
    return res.status(500).json({ error: "storage_failed" });
  } finally {
    client.release();
  }
});

app.get("/api/v1/locations", async (req, res) => {
  const claims = authenticate(req);
  if (!claims) return res.status(401).json({ error: "unauthorized" });
  if (!pool) return res.status(503).json({ error: "database_not_configured" });

  const limit = Math.min(Math.max(Number(req.query.limit ?? 100), 1), 500);
  const result = await pool.query(
    `SELECT id, latitude, longitude, accuracy, captured_at
     FROM location_points
     WHERE user_id = $1
     ORDER BY captured_at DESC
     LIMIT $2`,
    [claims.sub, limit]
  );

  return res.json({ points: result.rows });
});

app.listen(port, () => {
  console.log(`SPECTER LOCATE API listening on :${port}`);
});
