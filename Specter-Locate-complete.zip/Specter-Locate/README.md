# SPECTER LOCATE

SPECTER LOCATE is a consent-first Android location application with local history and an optional authenticated backend.

## Android

- Kotlin
- Jetpack Compose + Material 3
- Room local history
- Google Fused Location Provider
- Android foreground location service
- Runtime permissions
- Persistent tracking notification

Tracking is started by an explicit user action. The app does not bypass Android permissions or hide the foreground service.

Open the root project in Android Studio and build with Gradle.

## Backend

```bash
cd server
npm install
cp .env.example .env
npm run build
npm start
```

Required:
- DATABASE_URL
- JWT_SECRET
- PORT (optional)

Run `schema.sql` against PostgreSQL before using the location endpoints.

## API

`POST /api/v1/auth/demo`

```json
{"userId":"device-user-1"}
```

`POST /api/v1/locations/batch`

Requires `Authorization: Bearer <token>`.

`GET /api/v1/locations?limit=100`

Requires `Authorization: Bearer <token>`.

## Notes

The current Android client stores location history locally. Backend sync/auth wiring is isolated behind the API layer so a production deployment can add real identity, TLS, refresh tokens, device registration, retention controls, and encrypted transport configuration without changing the location collector.
