package com.specter.locate.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationDao {
    @Insert
    suspend fun insert(point: LocationPoint)

    @Query("SELECT * FROM location_points ORDER BY capturedAt DESC")
    fun observeAll(): Flow<List<LocationPoint>>

    @Query("SELECT * FROM location_points WHERE synced = 0 ORDER BY capturedAt ASC LIMIT 500")
    suspend fun pending(): List<LocationPoint>

    @Query("UPDATE location_points SET synced = 1 WHERE id IN (:ids)")
    suspend fun markSynced(ids: List<Long>)

    @Query("DELETE FROM location_points")
    suspend fun deleteAll()
}
