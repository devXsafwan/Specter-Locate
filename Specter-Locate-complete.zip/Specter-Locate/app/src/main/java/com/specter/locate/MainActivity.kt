package com.specter.locate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.specter.locate.data.AppDatabase
import com.specter.locate.data.LocationPoint
import com.specter.locate.location.LocationForegroundService
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private var startAfterPermission = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (startAfterPermission && hasLocationPermission()) {
                startLocationService()
            }
            startAfterPermission = false
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val dao = remember { AppDatabase.get(this).locationDao() }
            var points by remember { mutableStateOf(emptyList<LocationPoint>()) }
            var active by remember { mutableStateOf(false) }

            LaunchedEffect(Unit) {
                dao.observeAll().collectLatest { points = it }
            }

            SpecterTheme {
                SpecterLocateScreen(
                    active = active,
                    points = points,
                    onStart = {
                        if (hasLocationPermission()) {
                            startLocationService()
                            active = true
                        } else {
                            startAfterPermission = true
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                    Manifest.permission.POST_NOTIFICATIONS
                                )
                            )
                        }
                    },
                    onStop = {
                        stopService(Intent(this, LocationForegroundService::class.java))
                        active = false
                    },
                    onClear = {
                        kotlinx.coroutines.MainScope().launch { dao.deleteAll() }
                    }
                )
            }
        }
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun startLocationService() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, LocationForegroundService::class.java)
        )
    }
}

@Composable
private fun SpecterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF6EE7FF),
            secondary = Color(0xFF9B8CFF),
            background = Color(0xFF090B0F),
            surface = Color(0xFF11151B)
        ),
        content = content
    )
}

@Composable
private fun SpecterLocateScreen(
    active: Boolean,
    points: List<LocationPoint>,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onClear: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 28.dp)
        ) {
            item {
                Text(
                    "SPECTER LOCATE",
                    style = MaterialTheme.typography.headlineMedium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Your location. Under your control.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            if (active) "LIVE SHARING ACTIVE" else "LOCATION SHARING OFF",
                            color = if (active)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("${points.size} location points stored locally")
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Tracking starts only after you explicitly enable it.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                if (!active) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("START LOCATION SHARING")
                    }
                } else {
                    OutlinedButton(
                        onClick = onStop,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("STOP LOCATION SHARING")
                    }
                }
            }

            item {
                Text("RECENT LOCATION HISTORY", style = MaterialTheme.typography.titleMedium)
            }

            items(points.take(20), key = { it.id }) { point ->
                HistoryRow(point)
            }

            if (points.isNotEmpty()) {
                item {
                    TextButton(onClick = onClear) {
                        Text("Clear local history")
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(point: LocationPoint) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surface,
                RoundedCornerShape(14.dp)
            )
            .padding(15.dp)
    ) {
        Text(
            "%.6f, %.6f".format(point.latitude, point.longitude),
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(3.dp))
        Text(
            "Accuracy %.1fm · %s".format(
                point.accuracy,
                java.text.SimpleDateFormat(
                    "dd MMM yyyy, HH:mm",
                    java.util.Locale.getDefault()
                ).format(java.util.Date(point.capturedAt))
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
